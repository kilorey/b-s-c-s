package com.DJL.dao;

import com.DJL.pojo.LinkMan;
import com.DJL.utils.DruidUtil;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import java.sql.SQLException;
import java.util.List;

/**
 * @author DJL
 * @create 2021-11-07 23:19
 */
public class LinkManDao {
    private QueryRunner qr = new QueryRunner(DruidUtil.getDataSource());

    public List<LinkMan> findAll() throws Exception {
        String sql = "select * from linkman";
        List<LinkMan> list = qr.query(sql, new BeanListHandler<LinkMan>(LinkMan.class));
        return list;
    }

    public void add(LinkMan linkMan) throws SQLException {

        String sql = "insert into linkman values(null,?,?,?,?,?,?)";
        qr.update(sql,linkMan.getName(),linkMan.getSex(),linkMan.getAge(),linkMan.getAddress(),linkMan.getQq(),linkMan.getAddress());

    }

    public void deleteById(int id) throws Exception {
        String sql = "delete from linkman where id=?";
        qr.update(sql,id);

    }

    public LinkMan findOne(int id) throws Exception {
        String sql = "select * from linkman where id=?";
        LinkMan linkMan = qr.query(sql, new BeanHandler<LinkMan>(LinkMan.class), id);
        return linkMan;
    }

    public void update(LinkMan linkMan) throws Exception {
        String sql = "update linkman set name=?,sex=?,age=?,address=?,qq=?,email=? where id=?";
        qr.update(sql,linkMan.getName(),linkMan.getSex(),linkMan.getAge(),linkMan.getAddress(),linkMan.getQq(),linkMan.getEmail(),linkMan.getId());

    }

    public Long findTotalSize() throws Exception {
        String sql = "select count(*) from linkman";
        Long totalSize = (Long) qr.query(sql, new ScalarHandler());
        return totalSize;
    }

    public List<LinkMan> findPageList(Long currentPage, Integer pageSize) throws Exception {
        String sql = "select * from linkman limit ?,?";
        List<LinkMan> linkManList = qr.query(sql, new BeanListHandler<LinkMan>(LinkMan.class),(currentPage-1)*pageSize,pageSize);
        return linkManList;
    }
}
