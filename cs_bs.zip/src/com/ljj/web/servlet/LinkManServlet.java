package com.DJL.web.servlet;

import com.DJL.pojo.LinkMan;
import com.DJL.pojo.PageBean;
import com.DJL.service.LinkManService;
import com.sun.org.glassfish.gmbal.Description;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

/**
 * @author DJL
 * @create 2021-11-07 22:30
 */
@WebServlet("/linkman")
public class LinkManServlet extends HttpServlet {
    private LinkManService linkManService = new LinkManService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
       /**
        改进之前的代码
        if ("findAll".equals(action)) {
        findAll(req,resp);
        }
        if("add".equals(action)){
        add(req,resp);
        }
        if("findOne".equals(action)){
        findOne(req,resp);
        }
        if("delete".equals(action)){
        deleteById(req,resp);
        }
        if("update".equals(action)){
        update(req,resp);
        }
        if("findByPage".equals(action)){
        findByPage(req,resp);
        }
       */
       //通过反射改进之后的代码
        try {
            //根据方法名获取方法
            Method method = this.getClass().getDeclaredMethod(action, HttpServletRequest.class, HttpServletResponse.class);
            //执行方法
            method.invoke(this,req,resp);
        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req,resp);
    }
    /***
    * @description: 分页查询联系人
    * @param: [req, resp]
    * @return: void
    */
    private void findByPage(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        try {
            //1.前端页面的currentPage和pageSzize的值
            Long currentPage = Long.valueOf(req.getParameter("currentPage"));
            Integer pageSize = Integer.valueOf(req.getParameter("pageSize"));

            //2.调用业务层方法，查询当前页的pageBean
            PageBean<LinkMan> pageBean  = linkManService.findByPage(currentPage,pageSize);
            System.out.println(pageBean);
            //3.将pageBean对象存进request域对象中
            req.setAttribute("pageBean",pageBean);
        } catch (Exception e) {
            e.printStackTrace();
        }
        //4.跳转到list_page.jsp
        req.getRequestDispatcher("list_page.jsp").forward(req,resp);
    }


    /***
    * @description: 修改联系人
    * @param: [req, resp]
    * @return: void
    */
    private void update(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        try {
            Map<String, String[]> parameterMap = req.getParameterMap();
            LinkMan linkMan = new LinkMan();
            BeanUtils.populate(linkMan,parameterMap);
            linkManService.update(linkMan);
        } catch (Exception e) {
            e.printStackTrace();
        }
        resp.sendRedirect("linkman?action=findAll");
    }


    /***
    * @description: 通过id删除联系人
    * @param: [req, resp]
    * @return: void
    */
    private void deleteById(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        try {
            int id = Integer.valueOf(req.getParameter("id"));
            linkManService.deleteById(id);
            resp.sendRedirect("linkman?action=findAll");
        } catch (Exception e) {
            e.printStackTrace();
            resp.getWriter().write("删除失败");
        }

    }


    /***
    * @description: 查询一个联系人
    * @param: [req, resp]
    * @return: void
    */
    private void findOne(HttpServletRequest req, HttpServletResponse resp){

        try {
            int id = Integer.valueOf(req.getParameter("id"));
            LinkMan linkMan = linkManService.findOne(id);
            req.setAttribute("linkMan",linkMan);
            req.getRequestDispatcher("update.jsp").forward(req,resp);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /***
    * @description:删除联系人
    * @param: [req, resp]
    * @return: void
    */
    private void add(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        try {
            Map<String, String[]> parameterMap = req.getParameterMap();
            LinkMan linkMan = new LinkMan();
            BeanUtils.populate(linkMan, parameterMap);
            linkManService.add(linkMan);
            resp.sendRedirect("linkman?action=findAll");
        } catch (Exception e) {
            e.printStackTrace();
            resp.getWriter().write("添加失败");
        }

    }
    /*** 
    * @description: 查询所有联系人
    * @param: [req, resp]
    * @return: void
    */ 
    private void findAll(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
        try {
            //1.调用业务层方法，查询所有联系人信息
            List<LinkMan> listMan = null;
            listMan = linkManService.findAll();
            //2.将lisMan存入到request域对象当中
            req.setAttribute("list",listMan);
            //3.请求转发跳到list.jsp页面进行展示
            req.getRequestDispatcher("list.jsp").forward(req,resp);
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

}
