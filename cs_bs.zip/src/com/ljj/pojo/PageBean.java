package com.DJL.pojo;

import java.io.Serializable;
import java.util.List;

/**
 * @author DJL
 * @create 2021-11-10 13:40
 */
public class PageBean<T> implements Serializable {
    //总条数
    private Long totalSize;
    //总页数
    private Long totalPage;
    //当前页数
    private Long currentPage;
    //每页条数
    private Integer pageSize;
    //当前页的数据集合
    private List<T> list;

    public Long getTotalSize() {
        return totalSize;
    }

    public Long getTotalPage() {
        return totalPage;
    }

    public Long getCurrentPage() {
        return currentPage;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public List<T> getList() {
        return list;
    }

    public void setTotalSize(Long totalSize) {
        this.totalSize = totalSize;
    }

    public void setTotalPage(Long totalPage) {
        this.totalPage = totalPage;
    }

    public void setCurrentPage(Long currentPage) {
        this.currentPage = currentPage;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public void setList(List<T> list) {
        this.list = list;
    }

    @Override
    public String toString() {
        return "PageBean{" +
                "totalSize=" + totalSize +
                ", totalPage=" + totalPage +
                ", currentPage=" + currentPage +
                ", pageSize=" + pageSize +
                ", list=" + list +
                '}';
    }
}
