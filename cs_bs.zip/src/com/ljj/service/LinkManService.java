package com.DJL.service;
import com.DJL.dao.LinkManDao;
import com.DJL.pojo.LinkMan;
import com.DJL.pojo.PageBean;
import java.util.List;

/**
 * @author DJL
 * @create 2021-11-07 22:32
 */
public class LinkManService{
    private LinkManDao linkManDao = new LinkManDao();
    public List<LinkMan> findAll() throws Exception {
        return linkManDao.findAll();
    }

    public void add(LinkMan linkMan) throws Exception {
        linkManDao.add(linkMan);
    }

    public void deleteById(int id) throws Exception {
        linkManDao.deleteById(id);
    }


    public LinkMan findOne(int id) throws Exception {
        return linkManDao.findOne(id);
    }

    public void update(LinkMan linkMan) throws Exception {
        linkManDao.update(linkMan);
    }

    public PageBean<LinkMan> findByPage(Long currentPage, Integer pageSize) throws Exception {
        //1.创建一个pageBean对象
        PageBean<LinkMan> pageBean = new PageBean<>();
        //2.设置pageBean的五个属性
        //3.设置currentPage
        pageBean.setCurrentPage(currentPage);
        //4.设置pageSize
        pageBean.setPageSize(pageSize);
        //5.设置总条数，调用dao层方法，获取联系人总条数
        Long totalSize = linkManDao.findTotalSize();
        pageBean.setTotalSize(totalSize);
        //6.设置总页数
        Long totalPage = totalSize%pageSize==0 ? (totalSize/pageSize):(totalSize/pageSize)+1;
        pageBean.setTotalPage(totalPage);
        //7.设置list
        List<LinkMan> list = linkManDao.findPageList(currentPage,pageSize);
        pageBean.setList(list);

        return pageBean;
    }
}
